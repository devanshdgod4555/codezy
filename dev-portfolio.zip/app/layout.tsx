import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import JarvisBackground from "@/components/jarvis-background"
import JarvisInterface from "@/components/jarvis-interface"
import JarvisAssistant from "@/components/jarvis-assistant"
import MicroAnimations from "@/components/micro-animations"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Dev | WebWhizz",
  description: "Portfolio of Dev, CEO of WebWhizz - Web Developer & Designer",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <JarvisInterface />
          <JarvisBackground />
          <JarvisAssistant />
          <MicroAnimations />
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'